Follow below link for Code Details and Explanations:
http://jquerywall.com/multi-transfer-jquery-ui-selectable

For more cool jQuery stuff, visit us @ http://jquerywall.com

Happy jQuery Coding! :)