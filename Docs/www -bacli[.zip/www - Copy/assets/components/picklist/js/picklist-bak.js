$(function()
{
    $("#basic").pickList();
});
 